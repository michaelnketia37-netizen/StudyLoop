# StudyLoop V2 — Android Studio Build Guide
## Step-by-step fixes for every common error

---

## STEP 1 — Before Opening Android Studio

### Fix your internet & DNS first (do this once)
Open Command Prompt as Administrator and run:
```
ipconfig /flushdns
netsh winsock reset
```
Then restart your computer.

---

## STEP 2 — Open the Project

1. Extract the ZIP to a folder like `C:\Projects\StudyLoop`
   ⚠️ AVOID paths with spaces or special characters
   ❌ Bad:  `C:\My Projects\Study Loop`
   ✅ Good: `C:\Projects\StudyLoop`

2. Open Android Studio
3. Click **File → Open** → select the `StudyLoopMerged` folder
4. Wait for Gradle to sync (can take 5–15 minutes first time)

---

## STEP 3 — If Gradle Sync Fails

### Error: "Could not resolve..." or "Download failed"
Run this in Android Studio Terminal (bottom of screen):

**Windows:**
```
gradlew.bat dependencies --refresh-dependencies
```

**Mac/Linux:**
```
./gradlew dependencies --refresh-dependencies
```

---

### Error: "SDK location not found"
1. Open file `local.properties`
2. Make sure it says your SDK path, e.g.:
```
sdk.dir=C\:\\Users\\YourName\\AppData\\Local\\Android\\Sdk
```
Android Studio usually fixes this automatically.

---

### Error: "Minimum supported Gradle version is..."
Go to **File → Project Structure → Project**
Change Gradle version to **8.7**

---

### Error: Exit code 126 / Permission denied (Mac/Linux only)
Run in Terminal:
```
chmod +x gradlew
./gradlew build
```

---

### Error: "Could not download gradle-8.x-bin.zip"
Manually download Gradle:
1. Go to: https://gradle.org/releases/
2. Download `gradle-8.7-bin.zip`
3. Extract to: `C:\Users\YourName\.gradle\wrapper\dists\gradle-8.7-bin\`

---

### Error: "Failed to install the following Android SDK packages"
1. Go to **Tools → SDK Manager**
2. Make sure these are installed:
   - ✅ Android SDK Platform 35
   - ✅ Android SDK Build-Tools 35.0.0
   - ✅ Android SDK Platform-Tools
   - ✅ Android SDK Tools
3. Click **Apply** and let it download

---

### Error: "Kotlin version mismatch"
Go to **File → Settings → Plugins → Kotlin**
Update to latest version, then restart Android Studio.

---

### Error: "Hilt / Dagger annotation processor failed"
In Android Studio Terminal run:
```
gradlew.bat clean
gradlew.bat assembleDebug --stacktrace
```

---

### Error: "MPAndroidChart could not be resolved"
This needs JitPack. Make sure your `settings.gradle.kts` has:
```kotlin
maven { url = uri("https://jitpack.io") }
```
Already added ✅

---

### Error: "google-services.json not found"
The file is already inside:
`app/google-services.json` ✅
If Android Studio can't find it, copy it directly into the `app/` folder.

---

## STEP 4 — Force Re-download Everything

If many things failed to download, run these one by one in Terminal:

```
gradlew.bat clean
```
```
gradlew.bat assembleDebug --refresh-dependencies --no-build-cache
```

This forces Gradle to re-download everything fresh.

---

## STEP 5 — Build the APK

### Debug APK (for testing):
```
gradlew.bat assembleDebug
```
Output: `app/build/outputs/apk/debug/app-debug.apk`

### Release APK (for Play Store):
1. Go to **Build → Generate Signed Bundle/APK**
2. Choose **Android App Bundle (.aab)**
3. Create a new keystore:
   - Save it somewhere SAFE (Google Drive + USB)
   - Remember the password!
4. Fill in key alias and passwords
5. Click **Finish**

Output: `app/build/outputs/bundle/release/app-release.aab`

---

## STEP 6 — Get Your SHA-1

After building, run in Terminal:
```
gradlew.bat signingReport
```
Copy the **SHA-1** line and add it to:
**Firebase Console → Project Settings → Your App → Add Fingerprint**

---

## Common Error Code Reference

| Error | Cause | Fix |
|-------|-------|-----|
| Exit code 126 | Permission denied | `chmod +x gradlew` |
| Exit code 1 | General build fail | Run `--stacktrace` to see details |
| Exit code 2 | Gradle config error | Check build.gradle.kts syntax |
| TIMEOUT | Slow internet | Increase timeout in gradle.properties |
| OutOfMemoryError | Not enough RAM | Increase Xmx in gradle.properties |

---

## Still Stuck?

Paste the **exact error message** from the Build output tab and we'll fix it together.
The red text in **Build → Build Output** is what matters most.

