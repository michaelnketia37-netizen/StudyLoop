package com.michaelnketia.studyloop

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.michaelnketia.studyloop.databinding.ActivityMainBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var interstitialAd: InterstitialAd? = null
    private var navCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Navigation
        val navHost = supportFragmentManager
            .findFragmentById(R.id.nav_host) as NavHostFragment
        val navController = navHost.navController
        binding.bottomNav.setupWithNavController(navController)

        // Count tab switches — show interstitial every 6
        navController.addOnDestinationChangedListener { _, _, _ ->
            navCount++
            if (navCount % 6 == 0) showInterstitialAd()
        }

        // Banner Ad
        binding.adView.loadAd(AdRequest.Builder().build())
        binding.adView.adListener = object : AdListener() {
            override fun onAdLoaded() { binding.adView.visibility = View.VISIBLE }
            override fun onAdFailedToLoad(e: LoadAdError) { binding.adView.visibility = View.GONE }
        }

        // Preload interstitial
        loadInterstitialAd()

        // Handle deep-link from notification
        intent?.getStringExtra("TAB")?.let { tab ->
            when (tab) {
                "alarm"    -> binding.bottomNav.selectedItemId = R.id.nav_alarm
                "reminder" -> binding.bottomNav.selectedItemId = R.id.nav_reminder
            }
        }
    }

    private fun loadInterstitialAd() {
        InterstitialAd.load(
            this,
            App.INTERSTITIAL_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) { interstitialAd = ad }
                override fun onAdFailedToLoad(e: LoadAdError) { interstitialAd = null }
            }
        )
    }

    private fun showInterstitialAd() {
        interstitialAd?.let {
            it.show(this)
            interstitialAd = null
            loadInterstitialAd()
        }
    }

    override fun onPause() { binding.adView.pause(); super.onPause() }
    override fun onResume() { super.onResume(); binding.adView.resume() }
    override fun onDestroy() { binding.adView.destroy(); super.onDestroy() }
}
