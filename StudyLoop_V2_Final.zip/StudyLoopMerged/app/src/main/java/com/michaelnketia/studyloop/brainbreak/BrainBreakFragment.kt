package com.michaelnketia.studyloop.brainbreak

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.fragment.app.Fragment

/**
 * BrainBreakFragment — hosts the Brain Break games section.
 * Games (3D Chess, Going Balls, Sudoku, Tetris) are embedded in index.html
 * and loaded via the brainbreak tab. Individual games are loaded from:
 *   - file:///android_asset/chess_game_3d.html
 *   - file:///android_asset/going_ballspro.html
 */
class BrainBreakFragment : Fragment() {

    private var webView: WebView? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        webView = WebView(requireContext()).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
                loadWithOverviewMode = true
                useWideViewPort = true
                allowFileAccess = true
                allowContentAccess = true
                cacheMode = WebSettings.LOAD_DEFAULT
            }
            webViewClient = WebViewClient()
            loadUrl("file:///android_asset/index.html")
        }
        return webView!!
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        webView?.postDelayed({
            webView?.evaluateJavascript(
                "switchTab('brainbreak', document.getElementById('nav-brainbreak'));",
                null
            )
        }, 800)
    }

    override fun onDestroyView() {
        webView?.destroy()
        webView = null
        super.onDestroyView()
    }
}
