package com.michaelnketia.studyloop.whiteboard

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.fragment.app.Fragment

/**
 * WhiteboardFragment — renders the whiteboard canvas via the main WebView index.html.
 * The whiteboard is fully implemented in the HTML/JS layer (index.html) and navigated
 * to programmatically by triggering the 'whiteboard' tab via JS injection.
 */
class WhiteboardFragment : Fragment() {

    private var webView: WebView? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        webView = WebView(requireContext()).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
                loadWithOverviewMode = true
                useWideViewPort = true
                cacheMode = WebSettings.LOAD_DEFAULT
            }
            webViewClient = WebViewClient()
            loadUrl("file:///android_asset/index.html")
            // After load, switch to the whiteboard tab
            setOnClickListener {}
        }
        return webView!!
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // Navigate to whiteboard tab once page loads
        webView?.postDelayed({
            webView?.evaluateJavascript(
                "switchTab('whiteboard', document.getElementById('nav-whiteboard'));",
                null
            )
        }, 800)
    }

    override fun onDestroyView() {
        webView?.destroy()
        webView = null
        super.onDestroyView()
    }
}
