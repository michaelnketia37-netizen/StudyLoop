# StudyLoop V2 — Android App

**Your Personal Memory Coach** · Spaced repetition + productivity tools for students.

## What's New in V2

### 🖊️ Whiteboard
- Full canvas drawing tool with Pen, Pencil, Ruler (straight lines), and Eraser
- 8 colour palette + adjustable tip size slider
- Multi-page support (forward/backward page navigation, add pages)
- Undo / Redo (up to 40 steps per page)
- Auto-save after every stroke
- "Add to Study" — saves whiteboard as a Study Reminder or Note

### 🧩 Brain Break — 4 Games
- ♟️ **3D Chess** (Brain Chess Pro) — play vs AI, full 3D Three.js board
- 🔮 **Going Balls** — endless 3D runner, dodge obstacles
- 🔢 **Sudoku** — 3 difficulty levels, coin rewards
- 🟦 **Tetris** — classic with touch controls

### 📅 Review Sort (Study Reminders)
- **Today** tab — only shows items due today
- **This Week** tab — 7-day strip, tap any day to see its items
- **Months** tab — 12-month grid with year navigator (± 5 years)
  - Drill into any month → Week 1–4 (+ Week 5 for months with 29–31 days)
  - Accordion per week, tap to expand

### 🌍 6 Languages
English · French · Spanish · Arabic (RTL) · Portuguese · Hausa

### 🎨 Navigation
- Hamburger menu opens a **3-row grid popup** above the bottom bar
  - Row 1: Alarms · Study · Notes · To-Do
  - Row 2: Calc · Calendar · Break · More
  - Row 3: Whiteboard (centred, solo)
- Active tab chip shows current screen name next to the button

## Project Structure

```
app/src/main/
├── assets/
│   ├── index.html          ← Main WebView app (all UI)
│   ├── chess_game_3d.html  ← 3D Chess game
│   └── going_ballspro.html ← Going Balls game
├── java/com/michaelnketia/studyloop/
│   ├── alarm/              ← Alarms, Stopwatch, Countdown
│   ├── brainbreak/         ← BrainBreakFragment (NEW)
│   ├── calc/               ← Scientific calculator
│   ├── calendar/           ← Calendar view
│   ├── core/               ← Database, models, notifications
│   ├── notes/              ← Notes CRUD
│   ├── reminder/           ← Spaced repetition engine
│   ├── sync/               ← Firebase sync
│   ├── todo/               ← To-Do + widget
│   ├── whiteboard/         ← WhiteboardFragment (NEW)
│   ├── MainActivity.kt
│   ├── OnboardingActivity.kt
│   └── SettingsFragment.kt
└── res/
    ├── assets/             ← Game HTML files
    ├── layout/             ← XML layouts
    ├── mipmap-*/           ← App icons (all densities updated)
    ├── navigation/         ← nav_graph.xml (updated)
    ├── values/             ← strings, colors, themes
    └── values-{fr,es,ar,pt,ha}/  ← Translations
```

## Build

```bash
./gradlew assembleDebug
```

Requires: Android Studio Hedgehog+, JDK 17, Kotlin 1.9+

## Developer
Michael · Ghana 🇬🇭  
Version 2.0 · StudyLoop
