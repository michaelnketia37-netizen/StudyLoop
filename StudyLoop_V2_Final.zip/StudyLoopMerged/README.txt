═══════════════════════════════════════════════════════
  StudyLoop — Android Studio Project
  Developer:  Michael Nketia
  Email:      michaelnketia37@gmail.com
  Package:    com.michaelnketia.studyloop
  Version:    1.0 (versionCode: 1)
  Country:    Ghana 🇬🇭
═══════════════════════════════════════════════════════

HOW TO BUILD THE APK — STEP BY STEP
───────────────────────────────────────────────────────

STEP 1 — Install Android Studio
  • Download from: https://developer.android.com/studio
  • Install with default settings
  • Let it download the Android SDK automatically

STEP 2 — Open the Project
  • Open Android Studio
  • Click "Open" → navigate to this StudyLoop folder → click OK
  • Wait for Gradle to sync (first time: 5-10 minutes, downloads dependencies)
  • If prompted "Trust this project?" → click Trust

STEP 3 — Fix local.properties (if needed)
  • Android Studio usually sets this automatically
  • If you see SDK errors, open local.properties and set:
    sdk.dir=/path/to/your/Android/sdk

STEP 4 — Download gradle-wrapper.jar (IMPORTANT)
  • The gradle-wrapper.jar could not be included due to network restrictions
  • Android Studio will download it automatically on first sync
  • OR manually: go to File → Invalidate Caches → Restart
  • Then let Gradle sync complete

STEP 5 — Get SHA-1 for Firebase Google Sign-In
  • In Android Studio: View → Tool Windows → Gradle
  • Expand: StudyLoop → app → Tasks → android → signingReport
  • Double click signingReport
  • Copy the SHA-1 value from the Run output
  • Go to Firebase Console → Project Settings → Your Android App
  • Click "Add fingerprint" → paste SHA-1 → Save

STEP 6 — Build Signed APK
  • Build → Generate Signed Bundle / APK
  • Select "APK" → Next
  • Click "Create new..." to create a keystore:
      Key store path: save somewhere safe (e.g. Desktop/studyloop.jks)
      Password:       choose a strong password
      Key alias:      studyloop
      Key password:   same or different password
      Validity:       25 (years)
      First and Last Name: Michael Nketia
      Country Code:   GH
  • Click OK → Next
  • Select build variant: "release"
  • Click Finish
  • APK location: app/release/app-release.apk

⚠️  CRITICAL: NEVER lose your .jks keystore file or password.
    Without it you CANNOT publish updates to the same app on Play Store.
    Back it up to Google Drive, email it to yourself, etc.

STEP 7 — Upload to Google Play Store
  • Go to: https://play.google.com/console
  • Create new app → Android → Fill in details
  • Upload app-release.apk under "Release" → "Production"
  • Privacy Policy URL:
    https://michaelnketia37-netizen.github.io/studyloop-legal/
  • Add your playstore_icon_512.png as the app icon
  • Add playstore_feature_graphic_1024x500.png as feature graphic

═══════════════════════════════════════════════════════

PROJECT FILE STRUCTURE
───────────────────────────────────────────────────────
StudyLoop/
├── build.gradle.kts              ← Root Gradle (plugins)
├── settings.gradle.kts           ← Project settings
├── gradle.properties             ← Gradle config
├── local.properties              ← SDK path (auto-set)
├── gradlew                       ← Build script (Mac/Linux)
├── gradlew.bat                   ← Build script (Windows)
├── .gitignore
├── playstore_icon_512.png        ← Play Store icon
├── playstore_feature_graphic_1024x500.png
├── gradle/wrapper/
│   └── gradle-wrapper.properties
├── .idea/                        ← Android Studio settings
└── app/
    ├── build.gradle.kts          ← App Gradle (dependencies)
    ├── google-services.json      ← Firebase config ✅
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── assets/
        │   └── index.html        ← StudyLoop full app
        ├── java/com/michaelnketia/studyloop/
        │   ├── MainActivity.kt   ← WebView + AdMob
        │   ├── SplashActivity.kt ← Splash screen
        │   └── BootReceiver.kt   ← Alarm rescheduler
        └── res/
            ├── mipmap-mdpi/      ← Icon 48x48
            ├── mipmap-hdpi/      ← Icon 72x72
            ├── mipmap-xhdpi/     ← Icon 96x96
            ├── mipmap-xxhdpi/    ← Icon 144x144
            ├── mipmap-xxxhdpi/   ← Icon 192x192
            ├── mipmap-anydpi-v26/← Adaptive icon XML
            ├── layout/           ← XML layouts
            ├── values/           ← Colors, strings, themes
            ├── values-night/     ← Dark mode themes
            ├── drawable/         ← Backgrounds
            ├── drawable-v24/     ← Vector drawables
            ├── font/             ← App fonts
            └── xml/              ← Network security config

═══════════════════════════════════════════════════════

AD UNIT IDs
───────────────────────────────────────────────────────
AdMob App ID:        ca-app-pub-3085337059940131~9113241402
Banner Ad Unit:      ca-app-pub-3085337059940131/5253887448
Interstitial Ad:     ca-app-pub-3085337059940131/2758276537

═══════════════════════════════════════════════════════

FIREBASE SERVICES ENABLED
───────────────────────────────────────────────────────
✅ Firebase Analytics
✅ Firebase Authentication (Google Sign-In)
✅ Firebase Firestore (Cloud Sync)
✅ Firebase Crashlytics (Crash Reports)
✅ Firebase Cloud Messaging (Push Notifications)

═══════════════════════════════════════════════════════

LEGAL
───────────────────────────────────────────────────────
Privacy Policy & Terms of Use:
https://michaelnketia37-netizen.github.io/studyloop-legal/

═══════════════════════════════════════════════════════
Built with ❤️  by Michael Nketia · Ghana 🇬🇭
═══════════════════════════════════════════════════════
